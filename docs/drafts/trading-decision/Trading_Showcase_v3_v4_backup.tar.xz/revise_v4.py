from pathlib import Path
from copy import deepcopy
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import MSO_ANCHOR

ROOT = Path('/mnt/data')
SRC = ROOT / 'JunXLabs_Trading_Investment_and_AI_4pages_v3.pptx'
OUT = ROOT / 'JunXLabs_Trading_Investment_and_AI_4pages_v4.pptx'
prs = Presentation(SRC)
NAVY='173959'; INK='20384F'; MUTED='5C7083'; BLUE='245B8C'; LINE='D5DFE8'; WASH='F1F5F8'; WHITE='FFFFFF'

def edit(slide, idx, text, size=None, bold=None, color=None, x=None, y=None, w=None, h=None):
    sh = slide.shapes[idx]; tf = sh.text_frame; oldp = tf.paragraphs[0]
    oldpr = deepcopy(oldp._p.pPr) if oldp._p.pPr is not None else None
    oldr = deepcopy(oldp.runs[0]._r.rPr) if oldp.runs and oldp.runs[0]._r.rPr is not None else None
    tf.clear()
    for i, line in enumerate(text.split('\n')):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        if oldpr is not None:
            if p._p.pPr is not None: p._p.remove(p._p.pPr)
            p._p.insert(0, deepcopy(oldpr))
        r = p.add_run(); r.text = line
        if oldr is not None:
            if r._r.rPr is not None: r._r.remove(r._r.rPr)
            r._r.insert(0,deepcopy(oldr))
        r.font.name='Arial'
        if size is not None: r.font.size=Pt(size)
        if bold is not None: r.font.bold=bold
        if color: r.font.color.rgb=RGBColor.from_string(color)
        p.space_before=Pt(0); p.space_after=Pt(0)
    tf.word_wrap=True; tf.vertical_anchor=MSO_ANCHOR.TOP
    for k,v in [('left',x),('top',y),('width',w),('height',h)]:
        if v is not None: setattr(sh,k,Inches(v))
    return sh

def fill(slide, idx, color, line=LINE):
    sh=slide.shapes[idx]; sh.fill.solid(); sh.fill.fore_color.rgb=RGBColor.from_string(color)
    sh.line.color.rgb=RGBColor.from_string(line); sh.line.width=Pt(.8)

def linecolor(slide,idx,color=LINE):
    slide.shapes[idx].line.color.rgb=RGBColor.from_string(color)

def textbox(slide, text, x,y,w,h,size,bold=False,color=INK):
    sh=slide.shapes.add_textbox(Inches(x),Inches(y),Inches(w),Inches(h))
    tf=sh.text_frame; tf.word_wrap=True
    tf.margin_left=tf.margin_right=tf.margin_top=tf.margin_bottom=0
    p=tf.paragraphs[0]; p.text=text; p.font.name='Arial'; p.font.size=Pt(size)
    p.font.bold=bold; p.font.color.rgb=RGBColor.from_string(color)
    return sh

for i,s in enumerate(prs.slides):
    edit(s,4,'02  /  AI TRADING DECISION SYSTEMS',size=11.5,color=BLUE)
    edit(s,8,f'As of 01 Oct 2026   ·   v4   ·   {i+1} / 4',size=9.5,color=MUTED)

s=prs.slides[0]
edit(s,5,'INVESTMENT / PROJECT OVERVIEW',size=11.0)
edit(s,9,'Event-Driven Investment\nDecision Support',size=31.0,h=1.08)
edit(s,10,'This project combines my Ph.D. research and trading experience in an event-driven investment framework, supported by AI-assisted analysis.',size=17.5,y=2.83,h=.86)
edit(s,13,'Research Focus',size=18.5)
edit(s,14,'Study information diffusion, expectation gaps and changes in market pricing.',size=15.5,h=.52)
edit(s,17,'Investment Analysis',size=18.5)
edit(s,18,'Assess what price already reflects and which evidence could invalidate the thesis.',size=15.5,h=.52)
edit(s,21,'Portfolio Decisions',size=18.5)
edit(s,22,'Compare instruments, timing and size against existing exposure and potential loss.',size=15.5,h=.52)
for idx in [11,15,19]:
    for p in s.shapes[idx].text_frame.paragraphs:
        for r in p.runs:r.font.color.rgb=RGBColor.from_string(MUTED)
fill(s,23,WASH)
edit(s,24,'PROJECT SCOPE',size=11.5,color=BLUE)
linecolor(s,25,LINE)
edit(s,26,'Intended Use',size=19,bold=True,color=NAVY,y=2.63,h=.34)
edit(s,27,'Support research and decisions to enter, add, manage, hedge or exit positions.',size=16.0,color=INK,y=3.09,h=1.0)
edit(s,29,'In development; limited runtime prototype.',size=11.0,color=MUTED,y=6.16,h=.31)
linecolor(s,28,LINE)
textbox(s,'Role of AI',8.97,4.3,3.4,.35,19,True,NAVY)
textbox(s,'Organize evidence, test alternative explanations and retrieve relevant research and past cases.',8.97,4.77,3.4,1.03,16)
edit(s,7,'Basis: project owner’s research context and documented investment framework.',size=9.2)

s=prs.slides[1]
edit(s,5,'INVESTMENT / ANALYSIS & RISK',size=11.0)
edit(s,9,'Investment Analysis and Portfolio Risk',size=30.5)
edit(s,10,'Evaluate events relative to expectations, then assess the remaining opportunity and its portfolio implications.',size=17.2,h=.63)
for idx,text in [(13,'Pre-event context'),(18,'Event outcome'),(23,'Market response'),(28,'Trade assessment')]:
    edit(s,idx,text,size=16.1,h=.31)
for idx,text in [(14,'Expectations, positioning\nand price.'),(19,'Identify new facts and\nchanges to the thesis.'),(24,'Assess repricing,\noverreaction or no edge.'),(29,'Assess remaining edge\nand define invalidation.')]:
    edit(s,idx,text,size=14.2,h=.55)
edit(s,31,'Instrument and Timing',size=18.0)
edit(s,32,'Compare stock, options, spreads and no action. Assess expiry, implied volatility, liquidity and price confirmation, including the first pullback.',size=15.2,h=1.14)
edit(s,34,'Portfolio Risk and Sizing',size=18.0)
edit(s,35,'Assess shared exposures, leverage and downside scenarios. Apply Kelly only when probability and payoff assumptions are defensible.',size=15.2,h=1.14)
edit(s,37,'Position Management',size=18.0)
edit(s,38,'Separate long-term and tactical positions. Reassess adds and exits as evidence changes; recent P/L alone does not justify more risk.',size=15.2,h=1.14)
for idx in [30,33,36]:linecolor(s,idx,BLUE)
fill(s,39,WASH,WASH)
edit(s,40,'Decision review preserves the original information, subsequent actions and outcome.',size=12,color=MUTED)

s=prs.slides[2]
edit(s,9,'AI System Architecture',size=30.5)
edit(s,10,'Eight logical analysis roles combine account context, investment evidence and portfolio review.',size=17.2,h=.42)
edit(s,16,'Holdings · cash\nBuying power',size=13.3,h=.47)
edit(s,19,'Market & event data',size=15.2,h=.38)
edit(s,20,'Prices, news, catalysts\nand expectations · planned',size=12.3,h=.49)
edit(s,45,'Thesis and counter-thesis\nTrade alternatives\nPortfolio implications\nConfirmation / invalidation',size=14.4,h=1.26)
edit(s,47,'Human decision',size=14.0)
edit(s,52,'Target design. Full model-backed reasoning and Wiki/RAG retrieval are not yet implemented.',size=10.5)

s=prs.slides[3]
edit(s,5,'AI SYSTEM / IMPLEMENTATION',size=11.0)
edit(s,9,'Implementation Status and Next Steps',size=30.5,y=1.48,h=.62)
edit(s,10,'An initial account-data review path has been demonstrated. Investment reasoning and knowledge retrieval remain under development.',size=17.1,y=2.2,h=.69)
for idx in [11,18,23]:
    fill(s,idx,WASH); s.shapes[idx].top=Inches(3.11); s.shapes[idx].height=Inches(3.33)
edit(s,12,'DEMONSTRATED',size=11.2,color=BLUE,y=3.35)
edit(s,13,'Read-only Data Review',size=18.7,color=NAVY,y=3.81,h=.35)
edit(s,14,'A read-only Schwab snapshot reaches the rule-based review pipeline through SnapTrade.',size=15.7,color=INK,y=4.32,h=.94)
edit(s,15,'Holdings, cash, buying power and broker-reported total value reach the Decision Card.',size=15.0,color=INK,y=5.35,h=.79)
edit(s,17,'',size=11.0,color=MUTED)
s.shapes[16].line.fill.background()
edit(s,19,'NEXT / KNOWLEDGE',size=11.2,color=BLUE,y=3.35)
edit(s,20,'Knowledge Retrieval',size=18.7,y=3.81,h=.35)
edit(s,21,'Organize books, papers, research and personal cases in the five-library Wiki/RAG design.',size=15.7,color=INK,y=4.32,h=.94)
edit(s,22,'Link summaries to original evidence, counterexamples and decision records.',size=15.0,color=INK,y=5.35,h=.81)
edit(s,24,'NEXT / ANALYSIS & EVALUATION',size=10.4,color=BLUE,y=3.35)
edit(s,25,'Analysis and Evaluation',size=18.7,y=3.81,h=.35)
edit(s,26,'Implement specialist reasoning and portfolio scenario comparisons.',size=15.7,color=INK,y=4.32,h=.84)
edit(s,27,'Evaluate usefulness through historical cases, prospective decisions and post-trade review.',size=15.0,color=INK,y=5.35,h=.81)
edit(s,28,'Current boundary: single-account pilot with data gaps; no autonomous trading or validated investment performance.',size=11.5,bold=False,color=MUTED,y=6.67,h=.23)

repo='https://github.com/JXiang2020/ai-trading-decision-system/blob/main/'
notes=[
'PUBLIC SHOWCASE DRAFT v4 — 2026-10-01 baseline.\nUser direction: investment is the purpose; AI is a tool. Keep compelling subject matter but use factual, professional project language similar to Pillar 1.\nThe owner’s Ph.D. research connection comes from the owner-provided project narrative; no specific dissertation findings or demonstrated alpha are asserted.\nSources: '+repo+'source/system/Personal_AI_Trading_Decision_System_Handoff_v0.3.md'+'\n'+repo+'README.md',
'Investment framework, not an implemented strategy or a trading recommendation. Mechanisms remain candidates unless validated. First pullback is an execution heuristic, not a universal required stage. Kelly depends on defensible probability/payoff assumptions; no position size is proposed.\nSources: '+repo+'source/system/Personal_AI_Trading_Decision_System_Handoff_v0.3.md'+'\n'+repo+'docs/architecture/AI_Trading_Decision_System_Architecture_v0.7_Knowledge_System_2026-09-30.md',
'Target design, not eight deployed agents. Preserve all eight logical roles: Trading, Macro, Company & Event, Technical, Regime, Market Expectations & Pricing, Red-Team, Portfolio. Five library types are canonical categories, not separate services. Account data and active policies remain distinct from retrieved knowledge.\nSource: '+repo+'docs/architecture/AI_Trading_Decision_System_Architecture_v0.7_Knowledge_System_2026-09-30.md',
'Implementation claims refer to the recorded T005-C pilot, not a new test run in this revision. The connector handoff read one account; it did not independently authenticate from local Python or execute trades. Data gaps remained; review output was insufficient_data and Kelly not_estimable. Detailed account values and identifiers are excluded. Wiki/RAG, model-backed roles, full portfolio analytics and validated investment advantage are not claimed as completed.\nSources: '+repo+'reports/T005C_Execution_Report.md'+'\n'+repo+'README.md'
]
for s,n in zip(prs.slides,notes): s.notes_slide.notes_text_frame.text=n
prs.core_properties.title='AI Trading Decision Systems — Investment and AI Architecture'
prs.core_properties.subject='Public Showcase Draft v4 — professional narrative revision'
prs.core_properties.author='Jun Xiang'
prs.core_properties.keywords='JunXLabs, investment, event-driven, portfolio risk, AI decision support, draft'
prs.save(OUT)
print(OUT)
print('bytes',OUT.stat().st_size)
for version,presentation in [('v3',Presentation(SRC)),('v4',prs)]:
    md=[f'# Trading Decision Showcase — {version}', '', 'Status: Working draft, not approved for publication.', 'Baseline: 2026-10-01.', '']
    for i,sl in enumerate(presentation.slides):
        md += [f'## Page {i+1}', '']
        for shape in list(sl.shapes)[9:]:
            if shape.has_text_frame and shape.text.strip(): md += [shape.text, '']
        if version=='v4': md += ['### Source and scope notes',notes[i],'']
    (ROOT/'trading_v4_work'/f'Trading_Showcase_{version}_Content.md').write_text('\n'.join(md))
